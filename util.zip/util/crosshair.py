import tkinter as tk
from tkinter import colorchooser, ttk, messagebox
import json

class CrosshairCustomizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Crosshair Customizer")

        self.crosshair_color = "#FF0000"
        self.line_length = tk.IntVar(value=20)
        self.line_thickness = tk.IntVar(value=4)
        self.crosshair_enabled = tk.BooleanVar(value=True)
        self.crosshair_shape = tk.StringVar(value="Default")

        self.load_config()
        self.setup_ui()

        branding_label = tk.Label(self.root, text="1Dev Softworks LLC", font=("Arial", 8), anchor="w", bg="#f0f0f0")
        branding_label.grid(row=0, column=0, sticky="nw", padx=10, pady=5)

    def setup_ui(self):
        self.preview_frame = tk.Frame(self.root, bd=2, relief=tk.SUNKEN, bg="#f0f0f0", borderwidth=1, highlightbackground="#ddd", highlightcolor="#ddd")
        self.preview_frame.grid(row=1, column=0, padx=10, pady=10, rowspan=3)
        self.canvas = tk.Canvas(self.preview_frame, width=200, height=200, bg="white", highlightthickness=0)
        self.canvas.pack()
        self.draw_crosshair()

        tk.Label(self.root, text="Crosshair Color:", bg="#f0f0f0").grid(row=1, column=1, padx=10, sticky="w")
        color_button = tk.Button(self.root, text="Choose Color", command=self.choose_color, relief=tk.RAISED, borderwidth=1)
        color_button.grid(row=1, column=2, padx=10, pady=5)

        tk.Label(self.root, text="Crosshair Size:", bg="#f0f0f0").grid(row=2, column=1, padx=10, sticky="w")
        size_slider = ttk.Scale(self.root, from_=5, to_=50, variable=self.line_length, orient="horizontal", command=self.update_crosshair)
        size_slider.grid(row=2, column=2, padx=10, pady=5)

        tk.Label(self.root, text="Crosshair Thickness:", bg="#f0f0f0").grid(row=3, column=1, padx=10, sticky="w")
        thickness_slider = ttk.Scale(self.root, from_=1, to_=10, variable=self.line_thickness, orient="horizontal", command=self.update_crosshair)
        thickness_slider.grid(row=3, column=2, padx=10, pady=5)

        tk.Label(self.root, text="Crosshair Preset:", bg="#f0f0f0").grid(row=4, column=1, padx=10, sticky="w")
        preset_menu = ttk.Combobox(self.root, textvariable=self.crosshair_shape, values=["Default", "Dot"], state="readonly")
        preset_menu.grid(row=4, column=2, padx=10, pady=5)
        preset_menu.bind("<<ComboboxSelected>>", self.update_crosshair)

        save_button = tk.Button(self.root, text="Save & Show Crosshair", command=self.save_crosshair, relief=tk.RAISED, borderwidth=1)
        save_button.grid(row=5, column=1, pady=5)

        clear_button = tk.Button(self.root, text="Clear Crosshair", command=self.clear_crosshair, relief=tk.RAISED, borderwidth=1)
        clear_button.grid(row=5, column=2, pady=5)

        self.enable_disable_button = tk.Button(self.root, text="Disable Crosshair", command=self.toggle_crosshair, relief=tk.RAISED, borderwidth=1)
        self.enable_disable_button.grid(row=6, column=1, columnspan=2, pady=5)

    def choose_color(self):
        color = colorchooser.askcolor(initialcolor=self.crosshair_color)[1]
        if color:
            self.crosshair_color = color
            self.update_crosshair()

    def update_crosshair(self, *args):
        self.draw_crosshair()

    def draw_crosshair(self):
        self.canvas.delete("all")
        center_x, center_y = 100, 100
        line_length = self.line_length.get()
        line_thickness = self.line_thickness.get()
        shape = self.crosshair_shape.get()

        if shape == "Default":
            self.canvas.create_line(center_x - line_length, center_y, center_x + line_length, center_y, fill=self.crosshair_color, width=line_thickness)
            self.canvas.create_line(center_x, center_y - line_length, center_x, center_y + line_length, fill=self.crosshair_color, width=line_thickness)
        elif shape == "Dot":
            self.canvas.create_oval(center_x - line_thickness, center_y - line_thickness, center_x + line_thickness, center_y + line_thickness, fill=self.crosshair_color, outline="")

    def save_crosshair(self):
        config = {
            "color": self.crosshair_color,
            "line_length": self.line_length.get(),
            "line_thickness": self.line_thickness.get(),
            "crosshair_shape": self.crosshair_shape.get()
        }
        with open("config.json", "w") as config_file:
            json.dump(config, config_file)
        
        self.show_crosshair()
        messagebox.showinfo("Crosshair Saved", "Crosshair settings have been saved and applied.")

    def clear_crosshair(self):
        self.canvas.delete("all")
        self.remove_crosshair_from_screen()
        messagebox.showinfo("Crosshair Cleared", "Crosshair has been cleared from the preview and the screen.")

    def show_crosshair(self):
        if not self.crosshair_enabled.get():
            return

        self.overlay = tk.Toplevel()
        self.overlay.overrideredirect(True)
        self.overlay.attributes("-topmost", True)
        self.overlay.attributes("-transparentcolor", "white")
        self.overlay.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")

        self.overlay_canvas = tk.Canvas(self.overlay, width=self.root.winfo_screenwidth(), height=self.root.winfo_screenheight(), bg="white", highlightthickness=0)
        self.overlay_canvas.pack()

        self.draw_crosshair_on_overlay()

    def draw_crosshair_on_overlay(self):
        if not hasattr(self, 'overlay_canvas'):
            return

        self.overlay_canvas.delete("all")
        center_x, center_y = self.root.winfo_screenwidth() // 2, self.root.winfo_screenheight() // 2
        line_length = self.line_length.get()
        line_thickness = self.line_thickness.get()
        shape = self.crosshair_shape.get()

        if shape == "Default":
            self.overlay_canvas.create_line(center_x - line_length, center_y, center_x + line_length, center_y, fill=self.crosshair_color, width=line_thickness)
            self.overlay_canvas.create_line(center_x, center_y - line_length, center_x, center_y + line_length, fill=self.crosshair_color, width=line_thickness)
        elif shape == "Dot":
            self.overlay_canvas.create_oval(center_x - line_thickness, center_y - line_thickness, center_x + line_thickness, center_y + line_thickness, fill=self.crosshair_color, outline="")

    def remove_crosshair_from_screen(self):
        if hasattr(self, 'overlay') and self.overlay is not None:
            self.overlay.destroy()
            self.overlay = None
            self.overlay_canvas = None

    def toggle_crosshair(self):
        if self.crosshair_enabled.get():
            self.crosshair_enabled.set(False)
            self.enable_disable_button.config(text="Enable Crosshair")
            self.remove_crosshair_from_screen()
        else:
            self.crosshair_enabled.set(True)
            self.enable_disable_button.config(text="Disable Crosshair")
            self.show_crosshair()

    def load_config(self):
        try:
            with open("config.json", "r") as config_file:
                config = json.load(config_file)
                self.crosshair_color = config.get("color", "#FF0000")
                self.line_length.set(config.get("line_length", 20))
                self.line_thickness.set(config.get("line_thickness", 4))
                self.crosshair_shape.set(config.get("crosshair_shape", "Default"))
        except FileNotFoundError:
            pass

if __name__ == "__main__":
    root = tk.Tk()
    app = CrosshairCustomizer(root)
    root.mainloop()
